
<!-- README.md is generated from README.Rmd. Please edit that file -->

\-\> <https://shiny-u-bordeaux-covidsurv.apps.math.cnrs.fr>

# UBcovidsurv

`UBcovidsurv` encapsulate a shiny app

## Installation

You can install the development version from
[GitHub](https://github.com/borishejblum/UBcovidsurv):

``` r
#install.packages("devtools")
devtools::install_github("borishejblum/UBcovidsurv")
```

Then you can launch the app with:

``` r
UBcovidsurv::run_app()
```

## Deployed UBcovidsurv

  - Latest **development** version is deployed at
    <https://shiny-u-bordeaux-covidsurv.apps.math.cnrs.fr>

– Boris Hejblum
